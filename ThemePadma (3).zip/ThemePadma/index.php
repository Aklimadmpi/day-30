<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head();?>
</head>
<body>
    <!-- header part start -->
    <header class="container-fluid slider">
      <?php
      $qry1 = new WP_Query([
        'post_type'=>'post',
        'category_name'=>'slider'
      ]);
      ?>

      <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
 <div class="carousel-inner">
   <?php
   $x = 0;
   while($qry1->have_posts()){$qry1->the_post();
    $x++;
    ?>
   
    <div class="carousel-item <?= ($x==1)?'active':''?> ">
        <?php the_post_thumbnail();?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
    <?php 
    }
    ?>

    <!-- <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div> -->
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    </header>
    <!-- header part end -->
    <!-- logo part start -->
    <section class="container-fluid logo">
        <div class="row">
            <div class="col-sm-6 logo_left">
                <?php the_custom_logo();?>
            </div>
            <div class="col-sm-6 logo_right text-end">
                <?php dynamic_sidebar('bdlogo')?>
            </div>
        </div>
    </section>
    <!-- logo part end -->

    <!-- menu part start -->
    <section class="container-fluid menu_2  navbar-expand">
        <div class="container ">
            <?php wp_nav_menu(array(
                'theme_location'=> 'primary_menu',
                'menu_class'=>' navbar-nav menu_1',
            ) )
            ?>
        </div>
    </section>
    <!-- menu part end -->
    <!-- hero part start -->
    <section class="container hero text-center">
        <div class="row hero_top">
            <?php dynamic_sidebar('herotitle')?>
        </div>
       <div class="row">
        <div class="col-sm-4">
          <div class="card h-100" style="width: 18rem;">
          <?php dynamic_sidebar('herocard1');?>
      </div>
        </div>

          <div class="col-sm-4">
          <div class="card h-100" style="width: 18rem;">
          <?php dynamic_sidebar('herocard2');?>
      </div>
          </div>
        <div class="col-sm-4">
        <div class="card h-100" style="width: 18rem;">
          <?php dynamic_sidebar('herocard3');?>
      </div>
        </div>
       </div>
    </section>
    <!-- hero part end -->
    <!-- photo part start -->
    <section class="container photo-top text-center mt-5 mb-5">
      <div class="row">
       <div class="col-sm-5">
        <?php dynamic_sidebar('lineleft');?>
       </div>
       <div class="col-sm-2">
       <?php dynamic_sidebar('phototitle');?>
       </div>
       <div class="col-sm-5">
       <?php dynamic_sidebar('lineright');?>
       </div>
      </div>
      <div class="row">
        <div class="col-sm-3">
        <?php dynamic_sidebar('photocard1');?>
        </div>
        <div class="col-sm-3">
        <?php dynamic_sidebar('photocard2');?>
        </div>
        <div class="col-sm-3">
        <?php dynamic_sidebar('photocard3');?>
        </div>
        <div class="col-sm-3">
        <?php dynamic_sidebar('photocard4');?>
        </div>
      </div>
    </section>
    <!-- photo part end -->
    <!-- news part start -->
    <section class="container news">
    <?php
      $qry2 = new WP_Query([
        'post_type'=>'post',
        'category_name'=>'slider'
      ]);
      ?>

      <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
 <div class="carousel-inner">
   <?php
   $x = 0;
   while($qry2->have_posts()){$qry2->the_post();
    $x++;
    ?>
   
    <div class="carousel-item <?= ($x==1)?'active':''?> ">
        <?php the_title();?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
    <?php 
    }
    ?>

    <!-- <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div> -->
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
    </section>
    <!-- news part end -->
    <!-- footer part start -->
   <footer class="container-fluid">
   <div class="col-sm-6">
      <?php dynamic_sidebar('footerleft')?>
    </div>
    <div class="col-sm-6">2</div>
    <div class="row container">B</div>
   </div>
   </footer>
   
    <!-- footer part end -->

<?php wp_footer();?>
</body>
</html>